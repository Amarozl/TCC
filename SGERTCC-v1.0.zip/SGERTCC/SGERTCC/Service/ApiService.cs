﻿using APITCC.Model;
using System.Net.Http.Headers;

namespace SGERTCC.Service
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;


        public ApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Leitura>> GetLeituras(int conta, int comodo, int dispositivo, int dia, int mes, int ano, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync($"api/Leitura/Conta-{conta}-Comodo-{comodo}-Dispositivo-{dispositivo}-Data-d{dia}-m{mes}-a{ano}");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<Leitura>>();
        }

        public async Task<string> GetToken(string email, string senha)
        {
            // Construindo a URL com os parâmetros de email e senha
            var url = $"http://localhost:7122/api/Auth/login?Email={email}&Senha={senha}";

            // Faz a requisição POST para a API de login usando a URL com parâmetros
            var response = await _httpClient.PostAsync(url, null);

            // Verifica se a requisição foi bem-sucedida
            if (response.IsSuccessStatusCode)
            {
                // Lê o conteúdo da resposta e extrai o token
                var result = await response.Content.ReadFromJsonAsync<LoginResponse>();

                // Retorna o token JWT
                return result.Token;
            }
            else
            {
                // Caso a requisição falhe, trata o erro (exemplo: lançar uma exceção)
                throw new Exception("Erro ao obter o token: " + response.ReasonPhrase);
            }
        }

        // Classe auxiliar para representar a resposta do login
        public class LoginResponse
        {
            public string Token { get; set; }
        }
    }
}
