﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SGERTCC.Service;

namespace SGERTCC.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ApiService _apiSevice;

        public DashboardController(ApiService apiSevice)
        {
            _apiSevice = apiSevice;
        }

        public async Task<IActionResult> Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(int conta, int comodo, int dispositivo, int dia, int mes, int ano)
        {
            string email = "luccasamaroec2024@gmail.com";
            string senha = "1234";

            string token = await _apiSevice.GetToken(email, senha);

            var leituras = await _apiSevice.GetLeituras(conta, comodo, dispositivo, dia, mes, ano, token);
            if(leituras == null)
            {
                return BadRequest("Não foi possivel achar os dados");
            }

            ViewBag.leituras = leituras;

            return View();
        }


    }
}
