﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APITCC.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LeituraController : Controller
    {
        private readonly AppDbContext _context;

        public LeituraController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Leitura>>> GetLeitura()
        {
            return await _context.Leituras.ToListAsync();
        }

        // GET: api/Usuario/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Leitura>> GetLeitura(int id)
        {
            var usuario = await _context.Leituras.FirstOrDefaultAsync(u => u.LeituraID == id);

            if (usuario == null)
            {
                return NotFound();
            }

            return usuario;
        }

        [HttpPost("RegistrarLeitura")]
        public async Task<ActionResult> RegistrarLeitura([FromQuery] int dispositivoId, [FromQuery] double watts)
        {
            var leitura = new Leitura
            {
                fk_DispositivoID = dispositivoId,
                Watts = watts,
                DataLeitura = DateTime.Now
            };

            _context.Leituras.Add(leitura);
            await _context.SaveChangesAsync();

            return Ok("Leitura registrada com sucesso.");
        }
    }
}
