﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace APITCC.Model
{
    public class Leitura
    {
        [Key]
        public int LeituraID { get; set; }

        [Required]
        public double Watts { get; set; }

        [Required]
        public DateTime DataLeitura { get; set; }

        [ForeignKey("Dispositivo")]
        public int fk_DispositivoID { get; set; }
        public Dispositivo? Dispositivo { get; set; }
    }
}
