﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace APITCC.Model
{
    public class Conta
    {
        [Key]
        public int ContaID { get; set; }

        [Required]
        public string NomeConta { get; set; }

        [ForeignKey("Usuario")]
        public int fk_UsuarioID { get; set; }
        public Usuario? Usuario { get; set; }

        [JsonIgnore]
        public IList<Comodo>? Comodos { get; set; }
    }
}
