﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APITCC.Migrations
{
    /// <inheritdoc />
    public partial class mg4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Comodos_Contas_ContaID",
                table: "Comodos");

            migrationBuilder.DropForeignKey(
                name: "FK_Contas_Usuarios_UsuarioID",
                table: "Contas");

            migrationBuilder.DropForeignKey(
                name: "FK_Dispositivos_Comodos_ComodoID",
                table: "Dispositivos");

            migrationBuilder.DropForeignKey(
                name: "FK_Leituras_Dispositivos_DispositivoID",
                table: "Leituras");

            migrationBuilder.RenameColumn(
                name: "DispositivoID",
                table: "Leituras",
                newName: "fk_DispositivoID");

            migrationBuilder.RenameIndex(
                name: "IX_Leituras_DispositivoID",
                table: "Leituras",
                newName: "IX_Leituras_fk_DispositivoID");

            migrationBuilder.RenameColumn(
                name: "ComodoID",
                table: "Dispositivos",
                newName: "fk_ComodoID");

            migrationBuilder.RenameIndex(
                name: "IX_Dispositivos_ComodoID",
                table: "Dispositivos",
                newName: "IX_Dispositivos_fk_ComodoID");

            migrationBuilder.RenameColumn(
                name: "UsuarioID",
                table: "Contas",
                newName: "fk_UsuarioID");

            migrationBuilder.RenameIndex(
                name: "IX_Contas_UsuarioID",
                table: "Contas",
                newName: "IX_Contas_fk_UsuarioID");

            migrationBuilder.RenameColumn(
                name: "ContaID",
                table: "Comodos",
                newName: "fk_ContaID");

            migrationBuilder.RenameIndex(
                name: "IX_Comodos_ContaID",
                table: "Comodos",
                newName: "IX_Comodos_fk_ContaID");

            migrationBuilder.AlterColumn<string>(
                name: "Telefone",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Logradouro",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Estado",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Cidade",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "CEP",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddForeignKey(
                name: "FK_Comodos_Contas_fk_ContaID",
                table: "Comodos",
                column: "fk_ContaID",
                principalTable: "Contas",
                principalColumn: "ContaID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Contas_Usuarios_fk_UsuarioID",
                table: "Contas",
                column: "fk_UsuarioID",
                principalTable: "Usuarios",
                principalColumn: "UsuarioID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Dispositivos_Comodos_fk_ComodoID",
                table: "Dispositivos",
                column: "fk_ComodoID",
                principalTable: "Comodos",
                principalColumn: "ComodoID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Leituras_Dispositivos_fk_DispositivoID",
                table: "Leituras",
                column: "fk_DispositivoID",
                principalTable: "Dispositivos",
                principalColumn: "DispositivoID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Comodos_Contas_fk_ContaID",
                table: "Comodos");

            migrationBuilder.DropForeignKey(
                name: "FK_Contas_Usuarios_fk_UsuarioID",
                table: "Contas");

            migrationBuilder.DropForeignKey(
                name: "FK_Dispositivos_Comodos_fk_ComodoID",
                table: "Dispositivos");

            migrationBuilder.DropForeignKey(
                name: "FK_Leituras_Dispositivos_fk_DispositivoID",
                table: "Leituras");

            migrationBuilder.RenameColumn(
                name: "fk_DispositivoID",
                table: "Leituras",
                newName: "DispositivoID");

            migrationBuilder.RenameIndex(
                name: "IX_Leituras_fk_DispositivoID",
                table: "Leituras",
                newName: "IX_Leituras_DispositivoID");

            migrationBuilder.RenameColumn(
                name: "fk_ComodoID",
                table: "Dispositivos",
                newName: "ComodoID");

            migrationBuilder.RenameIndex(
                name: "IX_Dispositivos_fk_ComodoID",
                table: "Dispositivos",
                newName: "IX_Dispositivos_ComodoID");

            migrationBuilder.RenameColumn(
                name: "fk_UsuarioID",
                table: "Contas",
                newName: "UsuarioID");

            migrationBuilder.RenameIndex(
                name: "IX_Contas_fk_UsuarioID",
                table: "Contas",
                newName: "IX_Contas_UsuarioID");

            migrationBuilder.RenameColumn(
                name: "fk_ContaID",
                table: "Comodos",
                newName: "ContaID");

            migrationBuilder.RenameIndex(
                name: "IX_Comodos_fk_ContaID",
                table: "Comodos",
                newName: "IX_Comodos_ContaID");

            migrationBuilder.AlterColumn<string>(
                name: "Telefone",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Logradouro",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Estado",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Cidade",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CEP",
                table: "Usuarios",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Comodos_Contas_ContaID",
                table: "Comodos",
                column: "ContaID",
                principalTable: "Contas",
                principalColumn: "ContaID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Contas_Usuarios_UsuarioID",
                table: "Contas",
                column: "UsuarioID",
                principalTable: "Usuarios",
                principalColumn: "UsuarioID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Dispositivos_Comodos_ComodoID",
                table: "Dispositivos",
                column: "ComodoID",
                principalTable: "Comodos",
                principalColumn: "ComodoID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Leituras_Dispositivos_DispositivoID",
                table: "Leituras",
                column: "DispositivoID",
                principalTable: "Dispositivos",
                principalColumn: "DispositivoID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
