﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APITCC.Migrations
{
    /// <inheritdoc />
    public partial class mg5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Comodos_Contas_fk_ContaID",
                table: "Comodos");

            migrationBuilder.DropForeignKey(
                name: "FK_Contas_Usuarios_fk_UsuarioID",
                table: "Contas");

            migrationBuilder.DropForeignKey(
                name: "FK_Dispositivos_Comodos_fk_ComodoID",
                table: "Dispositivos");

            migrationBuilder.DropForeignKey(
                name: "FK_Leituras_Dispositivos_fk_DispositivoID",
                table: "Leituras");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Leituras",
                table: "Leituras");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Dispositivos",
                table: "Dispositivos");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Contas",
                table: "Contas");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Comodos",
                table: "Comodos");

            migrationBuilder.DropColumn(
                name: "Watts",
                table: "Dispositivos");

            migrationBuilder.DropColumn(
                name: "Watts",
                table: "Contas");

            migrationBuilder.DropColumn(
                name: "Watts",
                table: "Comodos");

            migrationBuilder.RenameTable(
                name: "Leituras",
                newName: "Leitura");

            migrationBuilder.RenameTable(
                name: "Dispositivos",
                newName: "Dispositivo");

            migrationBuilder.RenameTable(
                name: "Contas",
                newName: "ContaEnergia");

            migrationBuilder.RenameTable(
                name: "Comodos",
                newName: "Comodo");

            migrationBuilder.RenameIndex(
                name: "IX_Leituras_fk_DispositivoID",
                table: "Leitura",
                newName: "IX_Leitura_fk_DispositivoID");

            migrationBuilder.RenameIndex(
                name: "IX_Dispositivos_fk_ComodoID",
                table: "Dispositivo",
                newName: "IX_Dispositivo_fk_ComodoID");

            migrationBuilder.RenameIndex(
                name: "IX_Contas_fk_UsuarioID",
                table: "ContaEnergia",
                newName: "IX_ContaEnergia_fk_UsuarioID");

            migrationBuilder.RenameIndex(
                name: "IX_Comodos_fk_ContaID",
                table: "Comodo",
                newName: "IX_Comodo_fk_ContaID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Leitura",
                table: "Leitura",
                column: "LeituraID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Dispositivo",
                table: "Dispositivo",
                column: "DispositivoID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ContaEnergia",
                table: "ContaEnergia",
                column: "ContaID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Comodo",
                table: "Comodo",
                column: "ComodoID");

            migrationBuilder.AddForeignKey(
                name: "FK_Comodo_ContaEnergia_fk_ContaID",
                table: "Comodo",
                column: "fk_ContaID",
                principalTable: "ContaEnergia",
                principalColumn: "ContaID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ContaEnergia_Usuarios_fk_UsuarioID",
                table: "ContaEnergia",
                column: "fk_UsuarioID",
                principalTable: "Usuarios",
                principalColumn: "UsuarioID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Dispositivo_Comodo_fk_ComodoID",
                table: "Dispositivo",
                column: "fk_ComodoID",
                principalTable: "Comodo",
                principalColumn: "ComodoID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Leitura_Dispositivo_fk_DispositivoID",
                table: "Leitura",
                column: "fk_DispositivoID",
                principalTable: "Dispositivo",
                principalColumn: "DispositivoID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Comodo_ContaEnergia_fk_ContaID",
                table: "Comodo");

            migrationBuilder.DropForeignKey(
                name: "FK_ContaEnergia_Usuarios_fk_UsuarioID",
                table: "ContaEnergia");

            migrationBuilder.DropForeignKey(
                name: "FK_Dispositivo_Comodo_fk_ComodoID",
                table: "Dispositivo");

            migrationBuilder.DropForeignKey(
                name: "FK_Leitura_Dispositivo_fk_DispositivoID",
                table: "Leitura");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Leitura",
                table: "Leitura");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Dispositivo",
                table: "Dispositivo");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ContaEnergia",
                table: "ContaEnergia");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Comodo",
                table: "Comodo");

            migrationBuilder.RenameTable(
                name: "Leitura",
                newName: "Leituras");

            migrationBuilder.RenameTable(
                name: "Dispositivo",
                newName: "Dispositivos");

            migrationBuilder.RenameTable(
                name: "ContaEnergia",
                newName: "Contas");

            migrationBuilder.RenameTable(
                name: "Comodo",
                newName: "Comodos");

            migrationBuilder.RenameIndex(
                name: "IX_Leitura_fk_DispositivoID",
                table: "Leituras",
                newName: "IX_Leituras_fk_DispositivoID");

            migrationBuilder.RenameIndex(
                name: "IX_Dispositivo_fk_ComodoID",
                table: "Dispositivos",
                newName: "IX_Dispositivos_fk_ComodoID");

            migrationBuilder.RenameIndex(
                name: "IX_ContaEnergia_fk_UsuarioID",
                table: "Contas",
                newName: "IX_Contas_fk_UsuarioID");

            migrationBuilder.RenameIndex(
                name: "IX_Comodo_fk_ContaID",
                table: "Comodos",
                newName: "IX_Comodos_fk_ContaID");

            migrationBuilder.AddColumn<double>(
                name: "Watts",
                table: "Dispositivos",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "Watts",
                table: "Contas",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "Watts",
                table: "Comodos",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Leituras",
                table: "Leituras",
                column: "LeituraID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Dispositivos",
                table: "Dispositivos",
                column: "DispositivoID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Contas",
                table: "Contas",
                column: "ContaID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Comodos",
                table: "Comodos",
                column: "ComodoID");

            migrationBuilder.AddForeignKey(
                name: "FK_Comodos_Contas_fk_ContaID",
                table: "Comodos",
                column: "fk_ContaID",
                principalTable: "Contas",
                principalColumn: "ContaID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Contas_Usuarios_fk_UsuarioID",
                table: "Contas",
                column: "fk_UsuarioID",
                principalTable: "Usuarios",
                principalColumn: "UsuarioID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Dispositivos_Comodos_fk_ComodoID",
                table: "Dispositivos",
                column: "fk_ComodoID",
                principalTable: "Comodos",
                principalColumn: "ComodoID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Leituras_Dispositivos_fk_DispositivoID",
                table: "Leituras",
                column: "fk_DispositivoID",
                principalTable: "Dispositivos",
                principalColumn: "DispositivoID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
