﻿using APITCC.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Text;

namespace SGERTCC.Service
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;

        public ApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<dynamic> GetLeituras(int conta, int comodo, int dispositivo, int dia, int mes, int ano, string token)
        {
            var url = $"api/Leitura/Conta/{conta}/Comodo/{comodo}/Dispositivo/{dispositivo}/Ano/{ano}/Mes/{mes}/Dia/{dia}";

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<dynamic>(content);
            }

            return null;
        }

        public async Task<dynamic> GetContas(string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync("api/Conta");

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<dynamic>(content);
            }

            return null;
        }

        public async Task<dynamic> GetContaId(string token, int ContaId)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync($"api/Conta/{ContaId}");

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<dynamic>(content);
            }

            return null;
        }

        public async Task<dynamic> GetComodoPorConta(string token, int ContaId)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync($"api/Conta/{ContaId}/comodos");

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<dynamic>(content);
            }       

            return null;
        }

        public async Task<dynamic> GetUsuarios(string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync("api/Conta");

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<dynamic>(content);
            }

            return null;
        }

        public async Task<string> GetToken(string email, string senha)
        {
            var url = $"http://localhost:7122/api/Auth/login?Email={email}&Senha={senha}";

            var response = await _httpClient.PostAsync(url, null);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<LoginResponse>();
                return result.Token;
            }
            else
            {
                throw new Exception("Erro ao obter o token: " + response.ReasonPhrase);
            }
        }

        public async Task<bool> CreateContaAsync(string nomeConta, string token)
        {
            // Adiciona o token no cabeçalho da requisição
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var url = $"http://localhost:7122/api/Conta?NomeConta={nomeConta}";

            var response = await _httpClient.PostAsync(url, null);

            return response.IsSuccessStatusCode;

        }

        public async Task<HttpResponseMessage> CreateComodoAsync(Comodo comodo, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            return await _httpClient.PostAsJsonAsync("api/Comodo", comodo);
        }


        public class LoginResponse
        {
            public string Token { get; set; }
        }
    }
}