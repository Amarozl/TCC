﻿
function carregarMeses() {
    const anoSelecionado = document.getElementById('ano').value;
    const selectMes = document.getElementById('mes');
    selectMes.innerHTML = '<option selected disabled>Selecione o mês</option>';

    // Preenche os meses
    for (let i = 0; i < 12; i++) {
        selectMes.innerHTML += `<option value="${i + 1}">${mesesNomes[i]}</option>`;
    }

    // Habilita o campo de meses
    selectMes.disabled = false;
}

function carregarDias() {
    const mesSelecionado = document.getElementById('mes').value;
    const selectDia = document.getElementById('dia');
    const anoSelecionado = document.getElementById('ano').value;

    const diasNoMes = new Date(anoSelecionado, mesSelecionado, 0).getDate();
    selectDia.innerHTML = '<option selected disabled>Selecione o dia</option>';

    // Preenche os dias
    for (let i = 1; i <= diasNoMes; i++) {
        selectDia.innerHTML += `<option value="${i}">${i}</option>`;
    }

    // Habilita o campo de dias
    selectDia.disabled = false;
}