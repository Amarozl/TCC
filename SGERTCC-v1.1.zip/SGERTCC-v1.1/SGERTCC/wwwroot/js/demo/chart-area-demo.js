document.addEventListener("DOMContentLoaded", function () {
    atualizarGrafico();
});

function atualizarGrafico() {
    const tabelaCabecalho = document.querySelector('#tabela-dados thead th:first-child');

    if (tabelaCabecalho) {
        const filtroTexto = tabelaCabecalho.textContent.trim();
        console.log("Filtro detectado:", filtroTexto);

        let labels = [];
        let data = [];

        if (filtroTexto === 'Hora') {
            labels = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0') + 'h');
            data = carregarDadosDaTabela(labels, filtroTexto);
        } else if (filtroTexto === 'Dia') {
            labels = Array.from({ length: 31 }, (_, i) => `Dia ${i + 1}`);
            data = carregarDadosDaTabela(labels, filtroTexto);
        } else if (filtroTexto === 'M�s') {
            labels = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            data = carregarDadosDaTabela(labels, filtroTexto);
        }

        console.log("Labels ap�s ajuste:", labels);
        console.log("Data ap�s ajuste:", data);

        criarGrafico(labels, data, filtroTexto);
    } else {
        console.error("O cabe�alho da tabela n�o foi encontrado!");
    }
}

function carregarDadosDaTabela(labels, filtro) {
    const dataCompleta = {};

    labels.forEach(label => {
        dataCompleta[label] = 0;
    });

    document.querySelectorAll('#tabela-dados tbody tr').forEach(row => {
        const dataText = row.querySelector('td:nth-child(1)')?.textContent.trim() || '';
        const valueText = row.querySelector('td:nth-child(2)')?.textContent.trim() || '0';

        console.log("Linha da Tabela - Data:", dataText, "Value:", valueText);

        const parsedValue = parseFloat(valueText.replace(',', '.'));

        if (filtro === 'Hora') {
            const hora = dataText.padStart(2, '0') + 'h';
            if (dataCompleta.hasOwnProperty(hora)) {
                dataCompleta[hora] = parsedValue;
            }
        } else if (filtro === 'Dia') {
            const dia = 'Dia ' + dataText;
            if (dataCompleta.hasOwnProperty(dia)) {
                dataCompleta[dia] = parsedValue;
            }
        } else if (filtro === 'M�s') {
            const mesLabels = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            const mesIndex = mesLabels.indexOf(dataText);
            if (mesIndex !== -1) {
                const mesLabel = labels[mesIndex];
                dataCompleta[mesLabel] = parsedValue;
            }
        }
    });

    console.log("Data Completa ap�s preenchimento:", dataCompleta);

    return labels.map(label => dataCompleta[label]);
}

function criarGrafico(labels, data, unidade) {
    const ctx = document.getElementById("myAreaChart").getContext("2d");

    var gradientStroke = ctx.createLinearGradient(400, 0, 200, 0);
    gradientStroke.addColorStop(0, "rgba(186, 137, 248, 1)");
    gradientStroke.addColorStop(1, "rgba(208, 87, 245, 1)");

    new Chart(ctx, {
        type: "bar",
        data: {
            labels: labels,
            datasets: [{
                label: unidade,
                backgroundColor: gradientStroke,
                hoverBackgroundColor: "rgba(0, 188, 168, 1)",
                hoverBorderColor: "rgba(0, 188, 168, 1)",
                pointBorderWidth: 4,
                data: data
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                colors: {
                    forceOverride: true
                }
            },
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: labels.length
                    }
                }],
                yAxes: [{
                    ticks: {
                        padding: 10,
                        callback: function (value) {
                            return number_format(value, 4, ',', '.') + ' kWh';
                        },
                        min: 0,
                    },
                    gridLines: {
                        display: true,
                        drawBorder: false,
                        color: "rgba(3, 218, 198, 0.2)",
                        borderDash: [10],
                        zeroLineBorderDash: [8]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgba(3, 218, 198, 1)",
                bodyFontColor: "#000000",
                titleMarginBottom: 10,
                titleFontColor: '#000000',
                titleFontSize: 16,
                borderColor: 'rgba(0,0,0,0)',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: true,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function (tooltipItem) {
                        return number_format(tooltipItem.yLabel, 4, ',', '.') + ' kWh';
                    }
                }
            }
        }
    });
}

function number_format(number, decimals, dec_point, thousands_sep) {
    number = parseFloat(number).toFixed(decimals);
    var n = number.split('.');
    var integerPart = n[0];
    var decimalPart = n[1] ? dec_point + n[1] : '';

    var regex = /(\d+)(\d{3})/;
    while (regex.test(integerPart)) {
        integerPart = integerPart.replace(regex, '$1' + thousands_sep + '$2');
    }

    return integerPart + decimalPart;
}

atualizarGrafico();