﻿let total = 0;
let qtdkwh = document.querySelectorAll(".tkwh").length;
let val = 0;

for (let index = 0; index < qtdkwh; index++) {
    val = document.querySelectorAll(".tkwh")[index].innerText;
    val = val.replace(',', '.');
    console.log(val);
    val = parseFloat(val);
    total += val;
    totalformat = total.toFixed(4);
}

console.log(typeof (val));
if (document.querySelector(".tkwh") != null)
{
    document.querySelector("#gtstotal").innerHTML = totalformat;


    let media = totalformat / (document.querySelectorAll(".tkwh").length);

    let mediaformat = media.toFixed(4);


    document.querySelector("#gtsmedia").innerHTML = mediaformat;
}

