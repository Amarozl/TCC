﻿using APITCC.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using SGERTCC.Service;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Security.Cryptography;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SGERTCC.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ApiService _apiSevice;

        public DashboardController(ApiService apiSevice)
        {
            _apiSevice = apiSevice;
        }

        public async Task<IActionResult> Index()
        {
            string email = "luccasamaroec2024@gmail.com";
            string senha = "1234";

            // Obtenção do token de autenticação
            string token = await _apiSevice.GetToken(email, senha);

            // Chama o serviço da API para obter as leituras
            dynamic contas = await _apiSevice.GetContas(token);
            ViewBag.contas = contas;

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(int conta, int comodo, int dispositivo, int dia, int mes, int ano)
        {
            dynamic contas;
            string email = "luccasamaroec2024@gmail.com";
            string senha = "1234";

            // Obtenção do token de autenticação
            string token = await _apiSevice.GetToken(email, senha);

            // Chama o serviço da API para obter as leituras
            dynamic leituras = await _apiSevice.GetLeituras(conta, comodo, dispositivo, dia, mes, ano, token);

            if (leituras == null)
            {
                ViewBag.message = "Não foi possivel achar os dados!";
                contas = await _apiSevice.GetContas(token);
                ViewBag.contas = contas;
                return View();
            }

            // Passa as leituras para a View através do ViewBag
            ViewBag.Leituras = leituras;

            contas = await _apiSevice.GetContas(token);
            ViewBag.contas = contas;
            ViewBag.message = $"{dia}/{mes}/{ano}";

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> Conta(int id)
        {
            string email = "luccasamaroec2024@gmail.com";
            string senha = "1234";

            // Obtenção do token de autenticação
            string token = await _apiSevice.GetToken(email, senha);

            var ContaId = id;

            var nomeconta = await _apiSevice.GetContaId(token, id);

            ViewBag.nomeconta = nomeconta.nomeConta;

            dynamic comodos = await _apiSevice.GetComodoPorConta(token, ContaId);
            ViewBag.comodos = comodos;

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Conta(int id, int comodo, int dispositivo, int dia, int mes, int ano)
        {
            string email = "luccasamaroec2024@gmail.com";
            string senha = "1234";

            dynamic comodos;


            var ContaId = id;

            // Obtenção do token de autenticação
            string token = await _apiSevice.GetToken(email, senha);

            // Chama o serviço da API para obter as leituras
            dynamic leituras = await _apiSevice.GetLeituras(id, comodo, dispositivo, dia, mes, ano, token);

            if (leituras == null)
            {
                ViewBag.message = "Não foi possivel achar os dados!";
                comodos = await _apiSevice.GetComodoPorConta(token, ContaId);
                ViewBag.comodos = comodos;
                var nomeconta2 = await _apiSevice.GetContaId(token, id);
                ViewBag.nomeconta = nomeconta2.nomeConta;
                return View();
                
            }

            // Passa as leituras para a View através do ViewBag
            ViewBag.Leituras = leituras;
            ViewBag.ano = ano;
            ViewBag.mes = mes;
            ViewBag.dia = dia;

            var nomeconta = await _apiSevice.GetContaId(token, id);

            ViewBag.nomeconta = nomeconta.nomeConta;

            comodos = await _apiSevice.GetComodoPorConta(token, ContaId);
            ViewBag.comodos = comodos;
            ViewBag.message = $"{dia}/{mes}/{ano}";

            return View();
        }

        public async Task<IActionResult> ContaCreate()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ContaCreate(string nomeConta)
        {
            if (string.IsNullOrWhiteSpace(nomeConta))
            {
                ModelState.AddModelError(string.Empty, "Account name is required.");
                return View();
            }

            try
            {
                string email = "luccasamaroec2024@gmail.com";
                string senha = "1234";

                // Obtenção do token de autenticação
                string token = await _apiSevice.GetToken(email, senha);


                var success = await _apiSevice.CreateContaAsync(nomeConta, token);
            }
            catch
            {
                return BadRequest();
            }


            return View();
        }

        public async Task<IActionResult> ComodoCreate()
        {
            string email = "luccasamaroec2024@gmail.com";
            string senha = "1234";

            // Obtenção do token de autenticação
            string token = await _apiSevice.GetToken(email, senha);

            var contas =_apiSevice.GetContas(token).GetAwaiter().GetResult();

            ViewBag.Contas = new SelectList(contas, "contaID", "nomeConta");   
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ComodoCreate(Comodo comodo)
        {
            try
            {
                string email = "luccasamaroec2024@gmail.com";
                string senha = "1234";

                // Obtenção do token de autenticação
                string token = await _apiSevice.GetToken(email, senha);


                var success = await _apiSevice.CreateComodoAsync(comodo, token);
            }
            catch
            {
                return BadRequest();
            }


            return View();
        }
    }
}
