﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace APITCC.Model
{
    public class Dispositivo
    {
        [Key]
        public int DispositivoID { get; set; }

        [Required]
        public string NomeDispositivo { get; set; }

        [Required]
        public bool Status { get; set; }

        [ForeignKey("Comodo")]
        public int fk_ComodoID { get; set; }
        public Comodo? Comodo { get; set; }

        [JsonIgnore]
        public IList<Leitura>? Leituras { get; set; }
    }
}
