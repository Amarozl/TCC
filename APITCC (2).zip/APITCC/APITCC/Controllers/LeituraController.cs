﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APITCC.Controllers
{
    [Authorize] // Garante que o usuário deve estar autenticado
    [ApiController]
    [Route("api/[controller]")]
    public class LeituraController : ControllerBase
    {
        private readonly AppDbContext _context;

        public LeituraController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Leitura>>> GetLeitura()
        {
            return await _context.Leituras.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Leitura>> GetLeitura(int id)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(l => l.LeituraID == id);

            if (leitura == null)
            {
                return NotFound();
            }

            return leitura;
        }

        [HttpPost("RegistrarLeitura")]
        public async Task<ActionResult> RegistrarLeitura([FromQuery] int dispositivoId, [FromQuery] float watts)
        {
            var leitura = new Leitura
            {
                fk_DispositivoID = dispositivoId,
                Watts = watts,
                DataLeitura = DateTime.Now
            };

            _context.Leituras.Add(leitura);
            await _context.SaveChangesAsync();

            return Ok("Leitura registrada com sucesso.");
        }
    }
}