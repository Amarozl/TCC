﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APITCC.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContaController : Controller
    {
        private readonly AppDbContext _context;

        public ContaController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Conta
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Conta>>> GetContas()
        {
            return await _context.Contas
            .Include(c => c.Usuario) // Inclui o usuário relacionado
            .ToListAsync();
        }

        // GET: api/Conta/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Conta>> GetConta(int id)
        {
            var conta = await _context.Contas
            .Include(c => c.Usuario) // Inclui o usuário relacionado
            .FirstOrDefaultAsync(c => c.ContaID == id);

            if (conta == null)
            {
                return NotFound();
            }

            return conta;
        }

        // POST: api/Conta
        [HttpPost]
        public async Task<ActionResult<Conta>> PostConta(Conta conta)
        {
            _context.Contas.Add(conta);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetConta), new { id = conta.ContaID }, conta);
        }
    }
}
