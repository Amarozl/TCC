﻿using Microsoft.EntityFrameworkCore;
using APITCC.Model;

namespace APITCC.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Conta>().ToTable("ContaEnergia");
            modelBuilder.Entity<Comodo>().ToTable("Comodo");
            modelBuilder.Entity<Dispositivo>().ToTable("Dispositivo");
            modelBuilder.Entity<Leitura>().ToTable("Leitura");

            // Configurações adicionais, se necessárias
        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Conta> Contas { get; set; }
        public DbSet<Comodo> Comodos { get; set; }
        public DbSet<Dispositivo> Dispositivos { get; set; }
        public DbSet<Leitura> Leituras { get; set; }

    }
}
