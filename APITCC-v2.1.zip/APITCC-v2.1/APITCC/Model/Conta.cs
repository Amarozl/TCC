﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace APITCC.Model
{
    public class Conta
    {
        [Key]
        public int ContaID { get; set; }

        [Required]
        public string NomeConta { get; set; }


        [JsonIgnore]
        public IList<Comodo>? Comodos { get; set; }
    }
}
