﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APITCC.Migrations
{
    /// <inheritdoc />
    public partial class mg8 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ContaEnergia_Usuarios_fk_UsuarioID",
                table: "ContaEnergia");

            migrationBuilder.DropIndex(
                name: "IX_ContaEnergia_fk_UsuarioID",
                table: "ContaEnergia");

            migrationBuilder.DropColumn(
                name: "fk_UsuarioID",
                table: "ContaEnergia");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "fk_UsuarioID",
                table: "ContaEnergia",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_ContaEnergia_fk_UsuarioID",
                table: "ContaEnergia",
                column: "fk_UsuarioID");

            migrationBuilder.AddForeignKey(
                name: "FK_ContaEnergia_Usuarios_fk_UsuarioID",
                table: "ContaEnergia",
                column: "fk_UsuarioID",
                principalTable: "Usuarios",
                principalColumn: "UsuarioID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
