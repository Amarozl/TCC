﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APITCC.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ContaController : Controller
    {
        private readonly AppDbContext _context;

        public ContaController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Conta
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Conta>>> GetContas()
        {
            return await _context.Contas
            .Include(c => c.Comodos)
            .ToListAsync();
        }

        // GET: api/Conta/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Conta>> GetConta(int id)
        {
            var conta = await _context.Contas
            .FirstOrDefaultAsync(c => c.ContaID == id);

            if (conta == null)
            {
                return NotFound();
            }

            return conta;
        }

        [HttpGet("{id}/comodos")]
        public async Task<ActionResult<IEnumerable<Comodo>>> GetComodosByContaId(int id)
        {
            var conta = await _context.Contas
                .Include(c => c.Comodos)
                .FirstOrDefaultAsync(c => c.ContaID == id);

            if (conta == null)
            {
                return NotFound();
            }

            return Ok(conta.Comodos);
        }



        // POST: api/Conta
        [HttpPost]
        public async Task<ActionResult<Conta>> PostConta([FromQuery]Conta conta)
        {
            _context.Contas.Add(conta);
            await _context.SaveChangesAsync();

            return Ok();
        }
    }
}
