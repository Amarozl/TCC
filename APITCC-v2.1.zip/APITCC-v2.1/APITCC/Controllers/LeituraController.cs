﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APITCC.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class LeituraController : Controller
    {
        private readonly AppDbContext _context;

        public LeituraController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Leitura>>> GetLeituras()
        {
            return await _context.Leituras
            .ToListAsync();
        }

        [HttpGet("Ano{ano}")]
        public async Task<ActionResult<Leitura>> GetLeituraAno(int ano)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(a => a.DataLeitura.Year == ano);

            return leitura;
        }


        [HttpGet("Mes{mes}")]
        public async Task<ActionResult<Leitura>> GetLeituraMes(int mes)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(a => a.DataLeitura.Month == mes);

            return leitura;
        }

        [HttpGet("Dia{dia}")]
        public async Task<ActionResult<Leitura>> GetLeituraDia(int dia)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(a => a.DataLeitura.Day == dia);

            return leitura;
        }






        [HttpGet("Conta/{conta}/Comodo/{comodo}/Dispositivo/{dispositivo}/Ano/{ano}/Mes/{mes?}/Dia/{dia?}")]
        public async Task<ActionResult<IEnumerable<object>>> GetLeiturasFiltradas(int conta, int comodo, int dispositivo, int ano, int? mes, int? dia)
        {
            // Verificação: Se o dia for fornecido (não for 0), o mês também deve ser fornecido (não ser 0)
            if (dia != 0 && mes == 0)
            {
                return BadRequest("Para filtrar por dia, o mês deve ser fornecido.");
            }

            var leiturasQuery = _context.Leituras
                .Include(l => l.Dispositivo)
                .ThenInclude(d => d.Comodo)
                .ThenInclude(c => c.Conta)
                .AsQueryable();

            // Filtro por conta (se fornecido)
            if (conta > 0)
            {
                leiturasQuery = leiturasQuery.Where(l => l.Dispositivo.Comodo.fk_ContaID == conta);
            }

            // Filtro por cômodo (se fornecido)
            if (comodo > 0)
            {
                leiturasQuery = leiturasQuery.Where(l => l.Dispositivo.fk_ComodoID == comodo);
            }

            // Filtro por dispositivo (se fornecido), mas agregando se não for especificado
            if (dispositivo > 0)
            {
                leiturasQuery = leiturasQuery.Where(l => l.fk_DispositivoID == dispositivo);
            }

            // Filtro por ano (o ano é obrigatório, então sempre será aplicado)
            leiturasQuery = leiturasQuery.Where(l => l.DataLeitura.Year == ano);

            // Filtro por mês, se fornecido (mes != 0)
            if (mes != 0)
            {
                leiturasQuery = leiturasQuery.Where(l => l.DataLeitura.Month == mes.Value);
            }

            // Filtro por dia, se fornecido (dia != 0)
            if (dia != 0)
            {
                leiturasQuery = leiturasQuery.Where(l => l.DataLeitura.Day == dia.Value);
            }

            // Aplicar agrupamento e soma baseado nos filtros fornecidos
            List<object> resultado;

            if (dia != 0)
            {
                // Agrupamento por hora se o dia foi fornecido (somando para todos os dispositivos)
                resultado = await leiturasQuery
                    .GroupBy(l => l.DataLeitura.Hour)
                    .Select(g => new
                    {
                        Hora = g.Key,
                        TotalKWh = g.Sum(l => l.Watts)  // Soma para todos os dispositivos
                    })
                    .ToListAsync<object>();
            }
            else if (mes != 0)
            {
                // Agrupamento por dia se o mês foi fornecido (somando para todos os dispositivos)
                resultado = await leiturasQuery
                    .GroupBy(l => l.DataLeitura.Day)
                    .Select(g => new
                    {
                        Dia = g.Key,
                        TotalKWh = g.Sum(l => l.Watts)  // Soma para todos os dispositivos
                    })
                    .ToListAsync<object>();
            }
            else
            {
                // Agrupamento por mês se apenas o ano foi fornecido (somando para todos os dispositivos)
                resultado = await leiturasQuery
                    .GroupBy(l => l.DataLeitura.Month)
                    .Select(g => new
                    {
                        Mes = g.Key,
                        TotalKWh = g.Sum(l => l.Watts)  // Soma para todos os dispositivos
                    })
                    .ToListAsync<object>();
            }

            if (!resultado.Any())
            {
                return NotFound("Nenhuma leitura encontrada para os filtros aplicados.");
            }

            return Ok(resultado);
        }







        [HttpGet("{id}")]
        public async Task<ActionResult<Leitura>> GetLeitura(int id)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(l => l.LeituraID == id);

            if (leitura == null)
            {
                return NotFound();
            }

            return leitura;
        }


        [HttpPost("RegistrarLeitura")]
        public async Task<ActionResult> RegistrarLeitura([FromQuery] int dispositivoId, [FromQuery] float watts)
        {
            var leitura = new Leitura
            {
                fk_DispositivoID = dispositivoId,
                Watts = watts,
                DataLeitura = DateTime.Now
            };

            _context.Leituras.Add(leitura);
            await _context.SaveChangesAsync();

            return Ok("Leitura registrada com sucesso.");
        }
    }
}