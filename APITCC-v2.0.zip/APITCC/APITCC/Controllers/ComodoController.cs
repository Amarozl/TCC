﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APITCC.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ComodoController : Controller
    {
        private readonly AppDbContext _context;

        public ComodoController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Comodo
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Comodo>>> GetComodos()
        {
            return await _context.Comodos
                                 .Include(c => c.Conta.Usuario)
                                 .Include(c => c.Conta) // Inclui a Conta relacionado
                                 .Include(c => c.Dispositivos) // Inclui os dispositivos relacionados
                                 .ToListAsync();
        }

        // GET: api/Comodo/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Comodo>> GetComodo(int id)
        {
            var comodo = await _context.Comodos
                                       .Include(c => c.Conta) // Inclui a conta relacionado
                                       .Include(c => c.Dispositivos) // Inclui os dispositivos relacionados
                                       .FirstOrDefaultAsync(c => c.ComodoID == id);

            if (comodo == null)
            {
                return NotFound();
            }

            return comodo;
        }

        // POST: api/Comodo
        [HttpPost]
        public async Task<ActionResult<Comodo>> PostComodo(Comodo comodo)
        {
            _context.Comodos.Add(comodo);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetComodo), new { id = comodo.ComodoID }, comodo);
        }
    }
}
