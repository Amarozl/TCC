﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

namespace APITCC.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : Controller
    {
        private readonly AppDbContext _context;

        public UsuarioController(AppDbContext appCont)
        {
            _context = appCont;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Usuario>>> GetUsuarios()
        {
            return await _context.Usuarios
            .Include(u => u.Contas) // Inclui as contas relacionados
            .ToListAsync();
        }

        // GET: api/Usuario/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Usuario>> GetUsuario(int id)
        {
            var usuario = await _context.Usuarios
            .Include(u => u.Contas) // Inclui as contas relacionados
            .FirstOrDefaultAsync(u => u.UsuarioID == id);

            if (usuario == null)
            {
                return NotFound();
            }

            return usuario;
        }


        [HttpPost]
        [IgnoreAntiforgeryToken]
        public async Task<IActionResult> Create([Bind()] Usuario usuario)
        {
            var Email = usuario.Email;
            var CPF = usuario.CPF;

            if (_context.Usuarios.Where(i => i.Email == Email || i.CPF == CPF).FirstOrDefault() == null)
            {
                ViewBag.message = "Cadastro feito";
                if (ModelState.IsValid)
                {
                    // Hash the password
                    using (var sha256 = SHA256.Create())
                    {
                        var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(usuario.Senha));
                        usuario.Senha = BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
                    }

                    _context.Add(usuario);
                    await _context.SaveChangesAsync();

                    // Criar uma Conta associada ao Usuario
                    var conta = new Conta
                    {
                        NomeConta = "Conta 1",
                        fk_UsuarioID = usuario.UsuarioID,
                        Comodos = new List<Comodo>()
                    };

                    // Criar um Comodo associado à Conta
                    var comodo = new Comodo
                    {
                        NomeComodo = "Comodo 1",
                        fk_ContaID = conta.ContaID,
                        Dispositivos = new List<Dispositivo>()
                    };

                    // Criar um Dispositivo associado ao Comodo
                    var dispositivo = new Dispositivo
                    {
                        NomeDispositivo = "Dispositivo 1",
                        Status = false,
                        fk_ComodoID = comodo.ComodoID,
                        Leituras = new List<Leitura>()
                    };



                    // Adiciona o dispositivo ao comodo
                    comodo.Dispositivos.Add(dispositivo);

                    // Adiciona o comodo à conta
                    conta.Comodos.Add(comodo);

                    // Adiciona a conta ao usuário
                    usuario.Contas = new List<Conta> { conta };

                    // Salva as alterações no banco de dados
                    await _context.SaveChangesAsync();

                    return CreatedAtAction(nameof(GetUsuario), new { id = usuario.UsuarioID }, usuario);
                }
                return Ok("Usuário Registrado");
            }
            else
            {
                return BadRequest("Usuário já cadastrado!");
            }
        }
    }
}
