﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APITCC.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class LeituraController : Controller
    {
        private readonly AppDbContext _context;

        public LeituraController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Leitura>>> GetLeituras()
        {
            return await _context.Leituras
            .ToListAsync();
        }

        [HttpGet("Ano{ano}")]
        public async Task<ActionResult<Leitura>> GetLeituraAno(int ano)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(a => a.DataLeitura.Year == ano);

            return leitura;
        }


        [HttpGet("Mes{mes}")]
        public async Task<ActionResult<Leitura>> GetLeituraMes(int mes)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(a => a.DataLeitura.Month == mes);

            return leitura;
        }

        [HttpGet("Dia{dia}")]
        public async Task<ActionResult<Leitura>> GetLeituraDia(int dia)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(a => a.DataLeitura.Day == dia);

            return leitura;
        }






        [HttpGet("Conta-{conta}-Comodo-{comodo}-Dispositivo-{dispositivo}-Data-d{dia}-m{mes}-a{ano}")]
        public async Task<ActionResult<IEnumerable<Leitura>>> GetLeituraData(int conta, int comodo, int dispositivo, int dia, int mes, int ano)
        {
            // Obter todas as leituras
            var leiturasQuery = _context.Leituras.AsQueryable();

            // Verifique se o dispositivo existe
            if (dispositivo > 0)
            {
                var dispositivoExistente = await _context.Dispositivos.FindAsync(dispositivo);
                if (dispositivoExistente == null)
                {
                    return NotFound("O dispositivo especificado não existe.");
                }
                leiturasQuery = leiturasQuery.Where(l => l.fk_DispositivoID == dispositivo);
            }
            else if (comodo > 0)
            {
                var comodoExistente = await _context.Comodos.FindAsync(comodo);
                if (comodoExistente == null || !await _context.Dispositivos.AnyAsync(d => d.fk_ComodoID == comodo))
                {
                    return NotFound("O cômodo especificado não existe ou não contém dispositivos.");
                }
                leiturasQuery = leiturasQuery.Where(l => l.Dispositivo.fk_ComodoID == comodo);
            }
            else if (conta > 0)
            {
                var contaExistente = await _context.Contas.FindAsync(conta);
                if (contaExistente == null || !await _context.Comodos.AnyAsync(c => c.fk_ContaID == conta && _context.Dispositivos.Any(d => d.fk_ComodoID == c.ComodoID)))
                {
                    return NotFound("A conta especificada não existe ou não possui cômodos com dispositivos.");
                }
                leiturasQuery = leiturasQuery.Where(l => l.Dispositivo.Comodo.fk_ContaID == conta);
            }

            // Filtrar pela data
            if (dia != 0 && mes != 0 && ano != 0)
            {
                leiturasQuery = leiturasQuery.Where(l => l.DataLeitura.Day == dia && l.DataLeitura.Month == mes && l.DataLeitura.Year == ano);
            }
            else if (dia == 0 && mes != 0 && ano != 0)
            {
                leiturasQuery = leiturasQuery.Where(l => l.DataLeitura.Month == mes && l.DataLeitura.Year == ano);
            }
            else if (dia != 0 && (mes == 0 || ano == 0))
            {
                return BadRequest("O mês e o ano devem ser fornecidos quando o dia for especificado.");
            }
            else if (dia == 0 && mes == 0 && ano != 0)
            {
                leiturasQuery = leiturasQuery.Where(l => l.DataLeitura.Year == ano);
            }

            // Executar a consulta
            var leituras = await leiturasQuery.ToListAsync();

            // Verifica se há leituras
            if (!leituras.Any())
            {
                return NotFound("Nenhuma leitura encontrada.");
            }

            // Retornar todas as leituras correspondentes aos filtros aplicados
            return Ok(leituras);
        }







        [HttpGet("{id}")]
        public async Task<ActionResult<Leitura>> GetLeitura(int id)
        {
            var leitura = await _context.Leituras.FirstOrDefaultAsync(l => l.LeituraID == id);

            if (leitura == null)
            {
                return NotFound();
            }

            return leitura;
        }


        [HttpPost("RegistrarLeitura")]
        public async Task<ActionResult> RegistrarLeitura([FromQuery] int dispositivoId, [FromQuery] float watts)
        {
            var leitura = new Leitura
            {
                fk_DispositivoID = dispositivoId,
                Watts = watts,
                DataLeitura = DateTime.Now
            };

            _context.Leituras.Add(leitura);
            await _context.SaveChangesAsync();

            return Ok("Leitura registrada com sucesso.");
        }
    }
}