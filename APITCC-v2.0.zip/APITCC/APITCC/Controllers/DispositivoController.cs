﻿using APITCC.Context;
using APITCC.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace APITCC.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]

    public class DispositivoController : Controller
    {
        private readonly AppDbContext _context;

        public DispositivoController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Dispositivo
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Dispositivo>>> GetDispositivos()
        {
            return await _context.Dispositivos
                                 .Include(d => d.Comodo) // Inclui o comodo relacionado
                                 .ToListAsync();
        }

        // GET: api/Dispositivo/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Dispositivo>> GetDispositivo(int id)
        {
            var dispositivo = await _context.Dispositivos
                                            .Include(d => d.Comodo) // Inclui o comodo relacionado
                                            .FirstOrDefaultAsync(d => d.DispositivoID == id);

            if (dispositivo == null)
            {
                return NotFound();
            }

            return dispositivo;
        }

        // POST: api/Dispositivo
        [HttpPost]
        public async Task<ActionResult<Dispositivo>> PostDispositivo(Dispositivo dispositivo)
        {
            _context.Dispositivos.Add(dispositivo);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetDispositivo), new { id = dispositivo.DispositivoID }, dispositivo);
        }
    }
}
