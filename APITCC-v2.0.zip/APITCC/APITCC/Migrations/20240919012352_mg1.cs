﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APITCC.Migrations
{
    /// <inheritdoc />
    public partial class mg1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Usuarios",
                columns: table => new
                {
                    UsuarioID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Senha = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CPF = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DataNasc = table.Column<DateOnly>(type: "date", nullable: false),
                    CEP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Estado = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cidade = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Logradouro = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Telefone = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Usuarios", x => x.UsuarioID);
                });

            migrationBuilder.CreateTable(
                name: "ContaEnergia",
                columns: table => new
                {
                    ContaID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NomeConta = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    fk_UsuarioID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContaEnergia", x => x.ContaID);
                    table.ForeignKey(
                        name: "FK_ContaEnergia_Usuarios_fk_UsuarioID",
                        column: x => x.fk_UsuarioID,
                        principalTable: "Usuarios",
                        principalColumn: "UsuarioID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Comodo",
                columns: table => new
                {
                    ComodoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NomeComodo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    fk_ContaID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Comodo", x => x.ComodoID);
                    table.ForeignKey(
                        name: "FK_Comodo_ContaEnergia_fk_ContaID",
                        column: x => x.fk_ContaID,
                        principalTable: "ContaEnergia",
                        principalColumn: "ContaID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Dispositivo",
                columns: table => new
                {
                    DispositivoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NomeDispositivo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: false),
                    fk_ComodoID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Dispositivo", x => x.DispositivoID);
                    table.ForeignKey(
                        name: "FK_Dispositivo_Comodo_fk_ComodoID",
                        column: x => x.fk_ComodoID,
                        principalTable: "Comodo",
                        principalColumn: "ComodoID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Leitura",
                columns: table => new
                {
                    LeituraID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Watts = table.Column<double>(type: "float", nullable: false),
                    DataLeitura = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fk_DispositivoID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Leitura", x => x.LeituraID);
                    table.ForeignKey(
                        name: "FK_Leitura_Dispositivo_fk_DispositivoID",
                        column: x => x.fk_DispositivoID,
                        principalTable: "Dispositivo",
                        principalColumn: "DispositivoID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Comodo_fk_ContaID",
                table: "Comodo",
                column: "fk_ContaID");

            migrationBuilder.CreateIndex(
                name: "IX_ContaEnergia_fk_UsuarioID",
                table: "ContaEnergia",
                column: "fk_UsuarioID");

            migrationBuilder.CreateIndex(
                name: "IX_Dispositivo_fk_ComodoID",
                table: "Dispositivo",
                column: "fk_ComodoID");

            migrationBuilder.CreateIndex(
                name: "IX_Leitura_fk_DispositivoID",
                table: "Leitura",
                column: "fk_DispositivoID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Leitura");

            migrationBuilder.DropTable(
                name: "Dispositivo");

            migrationBuilder.DropTable(
                name: "Comodo");

            migrationBuilder.DropTable(
                name: "ContaEnergia");

            migrationBuilder.DropTable(
                name: "Usuarios");
        }
    }
}
