﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace APITCC.Model
{
    public class Comodo
    {
        [Key]
        public int ComodoID { get; set; }

        [Required]
        public string NomeComodo { get; set; }

        [ForeignKey("Conta")]
        public int fk_ContaID { get; set; }
        public Conta? Conta { get; set; }

        [JsonIgnore]
        public IList<Dispositivo>? Dispositivos { get; set; }
    }
}
